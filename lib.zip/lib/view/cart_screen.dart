import 'package:flutter/material.dart';
import 'package:market_nest/view/home_screen.dart';
import 'product_detail_screen.dart'; // for cartItems list

class CartScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final items = cartItems;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text("Cart"),
        centerTitle: true,
        backgroundColor: Colors.orange,
      ),
      body: items.isEmpty
          ? Center(child: Text("Cart is empty"))
          : Column(
              children: [
                Expanded(
                  child: ListView.builder(
                    padding: EdgeInsets.all(16),
                    itemCount: items.length,
                    itemBuilder: (context, index) {
                      final product = items[index];
                      return Card(
                        margin: EdgeInsets.only(bottom: 16),
                        child: ListTile(
                          leading: Image.network(
                            product.image,
                            width: 60,
                            height: 60,
                          ),
                          title: Text(product.title),
                          subtitle: Text(
                            "\$${product.price.toStringAsFixed(2)}",
                          ),
                          trailing: Icon(
                            Icons.check_circle,
                            color: Colors.green,
                          ),
                        ),
                      );
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(builder: (_) => HomeScreen()),
                        (route) => false,
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange,
                      minimumSize: Size(double.infinity, 50),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: Text(
                      "Checkout",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}
