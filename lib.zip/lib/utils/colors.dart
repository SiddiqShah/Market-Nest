import 'package:flutter/material.dart';

const Color whiteColor = Colors.white;

const Color greenColor = Color.fromARGB(255, 151, 198, 153);

const Color greyColor = Colors.grey;

const Color blackColor = Colors.black;

const Color yellowColor = Color(0xffF29D38);

const Color lightbrown = Color(0xffDDD5D5);
