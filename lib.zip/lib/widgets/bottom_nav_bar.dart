import 'package:flutter/material.dart';
import 'package:market_nest/utils/colors.dart';

class BottomNavBar extends StatefulWidget {
  const BottomNavBar({super.key});

  @override
  State<BottomNavBar> createState() => _BottomNavBarState();
}

class _BottomNavBarState extends State<BottomNavBar> {
  String selectedIcon = 'Home';

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 75,
      decoration: BoxDecoration(
        border: Border(top: BorderSide(width: 1.0, color: greyColor)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          NavBar(
            icon: Icons.home,
            title: "Home",
            isSelected: selectedIcon == "Home",
            onTap: () => setState(() => selectedIcon = "Home"),
          ),
          NavBar(
            icon: Icons.store,
            title: "Shop",
            isSelected: selectedIcon == "Shop",
            onTap: () => setState(() => selectedIcon = "Shop"),
          ),
          NavBar(
            icon: Icons.shopping_cart,
            title: "Cart",
            isSelected: selectedIcon == "Cart",
            onTap: () => setState(() => selectedIcon = "Cart"),
          ),
          NavBar(
            icon: Icons.person,
            title: "Profile",
            isSelected: selectedIcon == "Profile",
            onTap: () => setState(() => selectedIcon = "Profile"),
          ),
        ],
      ),
    );
  }
}

class NavBar extends StatelessWidget {
  final IconData icon;
  final String title;
  final bool isSelected;
  final VoidCallback onTap;

  const NavBar({
    super.key,
    required this.icon,
    required this.title,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: isSelected ? greenColor : greyColor, size: 25),
          SizedBox(height: 2),
          Text(
            title,
            style: TextStyle(
              color: isSelected ? greenColor : greyColor,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
}
